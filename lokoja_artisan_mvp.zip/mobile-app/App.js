import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import HomeScreen from './screens/HomeScreen';
import BookScreen from './screens/BookScreen';
import PaymentWebviewScreen from './screens/PaymentWebviewScreen';

const Stack = createNativeStackNavigator();

export default function App(){
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Book" component={BookScreen} />
        <Stack.Screen name="PaymentWebview" component={PaymentWebviewScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}