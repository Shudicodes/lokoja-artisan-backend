import React from 'react';
import { View, ActivityIndicator } from 'react-native';
import { WebView } from 'react-native-webview';

export default function PaymentWebviewScreen({ route, navigation }){
  const { url } = route.params;
  return (
    <View style={{flex:1}}>
      <WebView source={{ uri: url }} startInLoadingState renderLoading={() => <ActivityIndicator/>}
        onNavigationStateChange={(navState) => {
          // Example: if provider redirects to a success page, close and go back
          const successIndicator = 'payment-success'; // adapt to your provider
          if (navState.url.includes(successIndicator)) {
            navigation.popToTop();
            // You might refresh bookings list or show success screen
          }
        }}
      />
    </View>
  );
}