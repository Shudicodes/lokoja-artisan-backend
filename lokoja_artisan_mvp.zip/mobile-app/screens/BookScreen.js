import React, { useState } from 'react';
import { View, Text, Button, TextInput, Alert } from 'react-native';
import api from '../services/api';
import { Linking } from 'react-native';

export default function BookScreen({ route, navigation }){
  const { artisan } = route.params;
  const [amount,setAmount] = useState(String(artisan.price_from || '2000'));
  const [loading,setLoading] = useState(false);

  async function handleBook(){
    setLoading(true);
    try{
      const payload = { user_id: 1, artisan_id: artisan.id, service_category: artisan.category, amount: Number(amount) };
      const res = await api.post('/book', payload);
      const { payment_url } = res.data;
      // Open payment webview screen
      navigation.navigate('PaymentWebview', { url: payment_url });
    }catch(e){
      console.warn(e);
      Alert.alert('Error','Could not create booking');
    }
    setLoading(false);
  }

  return (
    <View style={{flex:1,padding:16}}>
      <Text style={{fontSize:18,fontWeight:'bold',marginBottom:8}}>Book {artisan.name}</Text>
      <Text>{artisan.category} — {artisan.city}</Text>
      <TextInput value={amount} onChangeText={setAmount} keyboardType='numeric' style={{borderWidth:1,padding:8,marginVertical:12}} />
      <Button title={loading ? 'Booking...' : 'Book & Pay'} onPress={handleBook} />
    </View>
  );
}