import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, ActivityIndicator } from 'react-native';
import api from '../services/api';

const categories = ["Electrician","Plumber","Carpenter","Painter","AC Repair","Mechanic"];

export default function HomeScreen({ navigation }){
  const [artisans,setArtisans] = useState([]);
  const [loading,setLoading] = useState(false);

  useEffect(()=>{ fetchArtisans('Electrician'); },[]);

  async function fetchArtisans(category){
    setLoading(true);
    try{
      const res = await api.get('/artisans', { params: { category, city: 'Lokoja' } });
      setArtisans(res.data);
    }catch(e){ console.warn(e); }
    setLoading(false);
  }

  return (
    <View style={{flex:1,padding:16}}>
      <Text style={{fontSize:20,fontWeight:'bold',marginBottom:12}}>Find a service in Lokoja</Text>
      <FlatList
        data={categories}
        horizontal
        keyExtractor={i=>i}
        renderItem={({item})=> (
          <TouchableOpacity onPress={()=>fetchArtisans(item)} style={{marginRight:10,padding:10,backgroundColor:'#eee',borderRadius:8}}>
            <Text>{item}</Text>
          </TouchableOpacity>
        )}
      />

      {loading ? <ActivityIndicator style={{marginTop:20}}/> : (
        <FlatList
          data={artisans}
          keyExtractor={a=>String(a.id)}
          renderItem={({item})=> (
            <TouchableOpacity onPress={()=>navigation.navigate('Book',{artisan:item})} style={{padding:12,borderBottomWidth:1}}>
              <Text style={{fontWeight:'bold'}}>{item.name} — {item.category}</Text>
              <Text>{item.price_from ? `From ₦${item.price_from}` : ''}</Text>
              <Text>{item.avg_rating ? `${item.avg_rating} ★` : ''}</Text>
            </TouchableOpacity>
          )}
        />
      )}
    </View>
  );
}