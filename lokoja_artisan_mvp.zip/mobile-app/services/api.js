import axios from 'axios';

const API_BASE = (typeof process !== 'undefined' && process.env && process.env.BACKEND_URL) ? process.env.BACKEND_URL : 'http://10.0.2.2:4000/api';

const instance = axios.create({ baseURL: API_BASE, timeout: 10000 });

export default instance;