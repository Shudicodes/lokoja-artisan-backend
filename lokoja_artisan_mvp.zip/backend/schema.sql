-- users table
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE,
  phone TEXT UNIQUE,
  role TEXT NOT NULL CHECK (role IN ('user','artisan','admin')),
  password_hash TEXT,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS artisans (
  id SERIAL PRIMARY KEY,
  user_id INT REFERENCES users(id) ON DELETE CASCADE,
  category TEXT NOT NULL,
  city TEXT,
  bio TEXT,
  price_from NUMERIC,
  avg_rating NUMERIC DEFAULT 0,
  verified BOOLEAN DEFAULT FALSE,
  profile_photo TEXT,
  id_document TEXT,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS bookings (
  id SERIAL PRIMARY KEY,
  user_id INT REFERENCES users(id),
  artisan_id INT REFERENCES artisans(id),
  service_category TEXT,
  scheduled_at TIMESTAMP,
  status TEXT DEFAULT 'pending',
  amount NUMERIC,
  payment_ref TEXT,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS payments (
  id SERIAL PRIMARY KEY,
  booking_id INT REFERENCES bookings(id),
  provider TEXT,
  provider_ref TEXT,
  amount NUMERIC,
  status TEXT,
  created_at TIMESTAMP DEFAULT now()
);